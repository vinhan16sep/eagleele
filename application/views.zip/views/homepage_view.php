<!-- InstanceBeginEditable name="content" -->

<section class="main-content container">
    <div id="index-slide" class="carousel slide" data-ride="carousel">
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <li data-target="#index-slide" data-slide-to="0" class="active"></li>
            <li data-target="#index-slide" data-slide-to="1"></li>
            <li data-target="#index-slide" data-slide-to="2"></li>
        </ol>

        <!-- Wrapper for slides -->
        <div class="carousel-inner" role="listbox">
            <div class="item active">
                <img src="<?php echo base_url('assets/public/img/slide-1.jpg'); ?>" alt="slide_1">
                <div class="carousel-caption">
                    Eagle Ele mang lại sự tự tin
                </div>
            </div>
            <div class="item">
                <img src="<?php echo base_url('assets/public/img/slide-2.jpg'); ?>" alt="slide_2">
                <div class="carousel-caption">
                    Khóa học dành cho doanh nhân
                </div>
            </div>
            <div class="item">
                <img src="<?php echo base_url('assets/public/img/slide-3.jpg'); ?>" alt="slide_2">
                <div class="carousel-caption">
                    Eagle Ele Việt Nam
                </div>
            </div>
        </div>

        <!-- Controls -->
        <a class="left carousel-control" href="#index-slide" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#index-slide" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
    <div class="row">
        <div class="index-course col-lg-9 col-md-9 col-sm-12 col-xs-12">
            <div class="content-title">
                <h2><?php echo $this->lang->line('index_course'); ?></h2>
                <div class="title-underline"></div>
            </div>
            <table class="table table-hover hidden-xs">
                <tr>
                    <td>
                        <h4 class="headline">30/7/2017</h4>
                        <h4 class="headline">Hà Nội</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc mattis est quam, id posuere nibh facilisis sed. Cras egestas commodo magna quis porttitor. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nullam ac lorem nec justo condimentum mollis.</p>
                    </td>
                    <td>
                        <a class="btn btn-default btn-fill" href="#" role="button" data-toggle="modal" data-target="#dangkykhoahoc">
                            <?php echo $this->lang->line('index_register'); ?>
                        </a>
                    </td>
                    <td>
                        <a class="btn btn-default" href="#" role="button">
                            <?php echo $this->lang->line('index_read_detail'); ?>
                        </a>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h4 class="headline">30/7/2017</h4>
                        <h4 class="headline">Hà Nội</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc mattis est quam, id posuere nibh facilisis sed. Cras egestas commodo magna quis porttitor. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nullam ac lorem nec justo condimentum mollis.</p>
                    </td>
                    <td>
                        <a class="btn btn-default btn-fill" href="#" role="button">
                            <?php echo $this->lang->line('index_register'); ?>
                        </a>
                    </td>
                    <td>
                        <a class="btn btn-default" href="#" role="button">
                            <?php echo $this->lang->line('index_read_detail'); ?>
                        </a>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h4 class="headline">30/7/2017</h4>
                        <h4 class="headline">Hà Nội</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc mattis est quam, id posuere nibh facilisis sed. Cras egestas commodo magna quis porttitor. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nullam ac lorem nec justo condimentum mollis.</p>
                    </td>
                    <td>
                        <a class="btn btn-default btn-fill" href="#" role="button">
                            <?php echo $this->lang->line('index_register'); ?>
                        </a>
                    </td>
                    <td>
                        <a class="btn btn-default" href="#" role="button">
                            <?php echo $this->lang->line('index_read_detail'); ?>
                        </a>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h4 class="headline">30/7/2017</h4>
                        <h4 class="headline">Hà Nội</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc mattis est quam, id posuere nibh facilisis sed. Cras egestas commodo magna quis porttitor. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nullam ac lorem nec justo condimentum mollis.</p>
                    </td>
                    <td>
                        <a class="btn btn-default btn-fill" href="#" role="button">
                            <?php echo $this->lang->line('index_register'); ?>
                        </a>
                    </td>
                    <td>
                        <a class="btn btn-default" href="#" role="button">
                            <?php echo $this->lang->line('index_read_detail'); ?>
                        </a>
                    </td>
                </tr>
            </table>

            <div class="visible-xs">
                <div class="course-xs col-xs-12">
                    <h4 class="headline">30/7/2017</h4>
                    <h4 class="headline">Hà Nội</h4>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc mattis est quam, id posuere nibh facilisis sed. Cras egestas commodo magna quis porttitor. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nullam ac lorem nec justo condimentum mollis.</p>
                    <a class="btn btn-default" href="#" role="button">
                        <?php echo $this->lang->line('index_read_detail'); ?>
                    </a>
                </div>

                <div class="course-xs col-xs-12">
                    <h4 class="headline">30/7/2017</h4>
                    <h4 class="headline">Hà Nội</h4>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc mattis est quam, id posuere nibh facilisis sed. Cras egestas commodo magna quis porttitor. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nullam ac lorem nec justo condimentum mollis.</p>
                    <a class="btn btn-default" href="#" role="button">
                        <?php echo $this->lang->line('index_read_detail'); ?>
                    </a>
                </div>

                <div class="course-xs col-xs-12">
                    <h4 class="headline">30/7/2017</h4>
                    <h4 class="headline">Hà Nội</h4>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc mattis est quam, id posuere nibh facilisis sed. Cras egestas commodo magna quis porttitor. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nullam ac lorem nec justo condimentum mollis.</p>
                    <a class="btn btn-default" href="#" role="button">
                        <?php echo $this->lang->line('index_read_detail'); ?>
                    </a>
                </div>
            </div>
        </div>
        <div class="index-side col-lg-3 col-md-3 hidden-sm hidden-xs">
            <div class="index-video">
                <iframe src="https://www.youtube.com/embed/3CangP9M5z0" frameborder="0" allowfullscreen></iframe>
            </div>
            <div class="index-banner">
                <img src="img/banner-100.jpg">
            </div>
        </div>
        <div class="index-coach col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="content-title">
                <h2><?php echo $this->lang->line('index_coach'); ?></h2>
                <div class="title-underline"></div>
            </div>
            <div class="index-coach-left col-lg-8 col-md-8 col-sm-8 col-xs-12">
                <div class="index-coach-left-item col-lg-3 col-md-3 col-sm-3 col-xs-6">
                    <img src="<?php echo base_url('assets/public/img/student-1.jpg'); ?>">
                    <label> Ông Hoàng Văn A</label>
                    <p>Chức vụ đang công tác</p>
                </div>
                <div class="index-coach-left-item col-lg-3 col-md-3 col-sm-3 col-xs-6">
                    <img src="<?php echo base_url('assets/public/img/student-2.jpg'); ?>">
                    <label> Ông Hoàng Văn A</label>
                    <p>Chức vụ đang công tác</p>
                </div>
                <div class="index-coach-left-item col-lg-3 col-md-3 col-sm-3 col-xs-6">
                    <img src="<?php echo base_url('assets/public/img/student-3.jpg'); ?>">
                    <label> Ông Hoàng Văn A</label>
                    <p>Chức vụ đang công tác</p>
                </div>
                <div class="index-coach-left-item col-lg-3 col-md-3 col-sm-3 col-xs-6">
                    <img src="<?php echo base_url('assets/public/img/student-1.jpg'); ?>">
                    <label> Ông Hoàng Văn A</label>
                    <p>Chức vụ đang công tác</p>
                </div>
            </div>
            <div class="index-coach-right col-lg-4 col-md-4 col-sm-4 col-xs-12">
                <label class="quote"> "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc mattis est quam"</label>

                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc mattis est quam, id posuere nibh facilisis sed. Cras egestas commodo magna quis porttitor. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nullam ac lorem nec justo condimentum mollis.</p>
                <a class="btn btn-default btn-fill" href="#" role="button">
                    <?php echo $this->lang->line('index_read_more'); ?>
                </a>
            </div>
        </div>
    </div>

    <!--<div class="row">
        <div class="content-title">
                <h2>Giáo trình tiêu biểu</h2>
            </div>
        <div id="index-books" class="carousel slide slide-books" data-ride="carousel">

          <ol class="carousel-indicators">
            <li data-target="#index-books" data-slide-to="0" class="active"></li>
            <li data-target="#index-books" data-slide-to="1"></li>
          </ol>


          <div class="carousel-inner" role="listbox">
            <div class="item active">
                  <div class="index-books-item col-lg-2 col-md-2 col-sm-2 col-xs-2">
                      <a href="#">
                          <img src="img/book-100.jpg">
                        <label class="slide-book-name">Cuốn sách hay I</label>
                    </a>
                </div>
                <div class="index-books-item col-lg-2 col-md-2 col-sm-2 col-xs-2">
                      <a href="#">
                          <img src="img/book-100.jpg">
                        <label class="slide-book-name">Cuốn sách hay I</label>
                    </a>
                </div>
                <div class="index-books-item col-lg-2 col-md-2 col-sm-2 col-xs-2">
                      <a href="#">
                          <img src="img/book-100.jpg">
                        <label class="slide-book-name">Cuốn sách hay I</label>
                    </a>
                </div>
                <div class="index-books-item col-lg-2 col-md-2 col-sm-2 col-xs-2">
                      <a href="#">
                          <img src="img/book-100.jpg">
                        <label class="slide-book-name">Cuốn sách hay I</label>
                    </a>
                </div>
                <div class="index-books-item col-lg-2 col-md-2 col-sm-2 col-xs-2">
                      <a href="#">
                          <img src="img/book-100.jpg">
                        <label class="slide-book-name">Cuốn sách hay I</label>
                    </a>
                </div>
                <div class="index-books-item col-lg-2 col-md-2 col-sm-2 col-xs-2">
                      <a href="#">
                          <img src="img/book-100.jpg">
                        <label class="slide-book-name">Cuốn sách hay I</label>
                    </a>
                </div>
            </div>

            <div class="item">
                <div class="index-books-item col-lg-2 col-md-2 col-sm-2 col-xs-2">
                      <a href="#">
                          <img src="img/book-100.jpg">
                        <label class="slide-book-name">Cuốn sách hay I</label>
                    </a>
                </div>
                <div class="index-books-item col-lg-2 col-md-2 col-sm-2 col-xs-2">
                      <a href="#">
                          <img src="img/book-100.jpg">
                        <label class="slide-book-name">Cuốn sách hay I</label>
                    </a>
                </div>
                <div class="index-books-item col-lg-2 col-md-2 col-sm-2 col-xs-2">
                      <a href="#">
                          <img src="img/book-100.jpg">
                        <label class="slide-book-name">Cuốn sách hay I</label>
                    </a>
                </div>
                <div class="index-books-item col-lg-2 col-md-2 col-sm-2 col-xs-2">
                      <a href="#">
                          <img src="img/book-100.jpg">
                        <label class="slide-book-name">Cuốn sách hay I</label>
                    </a>
                </div>
            </div>
          </div>

        </div>
    </div>-->

    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="content-title">
                <h2><?php echo $this->lang->line('index_clients'); ?></h2>
                <div class="title-underline"></div>
            </div>
            <div id="index-customers" class="carousel slide slide-customers" data-ride="carousel">
                <!-- Indicators -->
                <ol class="carousel-indicators">
                    <li data-target="#index-customers" data-slide-to="0" class="active"></li>
                    <li data-target="#index-customers" data-slide-to="1"></li>
                </ol>

                <!-- Wrapper for slides -->
                <div class="carousel-inner" role="listbox">
                    <div class="item active">
                        <div class="index-books-item col-lg-2 col-md-2 col-sm-2 col-xs-4">
                            <a href="#">
                                <img src="<?php echo base_url('assets/public/img/logo-client-01.png'); ?>">
                            </a>
                        </div>
                        <div class="index-books-item col-lg-2 col-md-2 col-sm-2 col-xs-4">
                            <a href="#">
                                <img src="<?php echo base_url('assets/public/img/logo-client-02.png'); ?>">
                            </a>
                        </div>
                        <div class="index-books-item col-lg-2 col-md-2 col-sm-2 col-xs-4">
                            <a href="#">
                                <img src="<?php echo base_url('assets/public/img/logo-client-03.png'); ?>">
                            </a>
                        </div>
                        <div class="index-books-item col-lg-2 col-md-2 col-sm-2 col-xs-4">
                            <a href="#">
                                <img src="<?php echo base_url('assets/public/img/logo-client-04.png'); ?>">
                            </a>
                        </div>
                        <div class="index-books-item col-lg-2 col-md-2 col-sm-2 col-xs-4">
                            <a href="#">
                                <img src="<?php echo base_url('assets/public/img/logo-client-05.png'); ?>">
                            </a>
                        </div>
                        <div class="index-books-item col-lg-2 col-md-2 col-sm-2 col-xs-4">
                            <a href="#">
                                <img src="<?php echo base_url('assets/public/img/logo-client-06.png'); ?>">
                            </a>
                        </div>
                    </div>

                    <div class="item">
                        <div class="index-books-item col-lg-2 col-md-2 col-sm-2 col-xs-4">
                            <a href="#">
                                <img src="<?php echo base_url('assets/public/img/logo-client-07.png'); ?>">
                            </a>
                        </div>
                        <div class="index-books-item col-lg-2 col-md-2 col-sm-2 col-xs-4">
                            <a href="#">
                                <img src="<?php echo base_url('assets/public/img/logo-client-08.png'); ?>">
                            </a>
                        </div>
                        <div class="index-books-item col-lg-2 col-md-2 col-sm-2 col-xs-4">
                            <a href="#">
                                <img src="<?php echo base_url('assets/public/img/logo-client-09.png'); ?>">
                            </a>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>

    <div class="row">
        <div class="index-about col-lg-4 col-md-4 col-sm-4 col-xs-12">
            <div class="content-title">
                <h2><?php echo $this->lang->line('index_about_us'); ?></h2>
                <div class="title-underline"></div>
            </div>

            <img src="<?php echo base_url('assets/public/img/index_aboutus.jpg'); ?>">
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc mattis est quam, id posuere nibh facilisis sed. Cras egestas commodo magna quis porttitor.</p>
        </div>

        <div class="index-news col-lg-4 col-md-4 col-sm-4 col-xs-12">
            <div class="content-title">
                <h2><?php echo $this->lang->line('index_news'); ?></h2>
                <div class="title-underline"></div>
            </div>
            <ul>
                <li>
                    <a href="news-post.html">Tin tức và sự kiện mới nhất được cập nhật</a>
                </li>
                <li>
                    <a href="news-post.html">Tin tức và sự kiện mới nhất được cập nhật</a>
                </li>
                <li>
                    <a href="news-post.html">Tin tức và sự kiện mới nhất được cập nhật</a>
                </li>
                <li>
                    <a href="news-post.html">Tin tức và sự kiện mới nhất được cập nhật</a>
                </li>
                <li>
                    <a href="news-post.html">Tin tức và sự kiện mới nhất được cập nhật</a>
                </li>
                <li>
                    <a href="news-post.html">Tin tức và sự kiện mới nhất được cập nhật</a>
                </li>
            </ul>
        </div>

        <div class="index-comment col-lg-4 col-md-4 col-sm-4 col-xs-12">
            <div class="content-title">
                <h2><?php echo $this->lang->line('index_student_thinking'); ?></h2>
                <div class="title-underline"></div>
            </div>
            <div id="index-comment" class="carousel slide slide-comment" data-ride="carousel">
                <!-- Indicators -->
                <ol class="carousel-indicators">
                    <li data-target="#index-comment" data-slide-to="0" class="active"></li>
                    <li data-target="#index-comment" data-slide-to="1"></li>
                </ol>

                <!-- Wrapper for slides -->
                <div class="carousel-inner" role="listbox">
                    <div class="item active">
                        <div class="index-comment-item">
                            <div class="left">
                                <img src="<?php echo base_url('assets/public/img/student-2.jpg'); ?>">
                            </div>
                            <div class="right">
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc mattis est quam, id posuere nibh facilisis sed. Cras egestas commodo magna quis porttitor.</p>
                                <p class="note">
                                    Ngô Xuân Lan <br>
                                    Trưởng phòng Marketing VCB
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="item">
                        <div class="index-comment-item">
                            <div class="left">
                                <img src="<?php echo base_url('assets/public/img/student-1.jpg'); ?>">
                            </div>
                            <div class="right">
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc mattis est quam, id posuere nibh facilisis sed. Cras egestas commodo magna quis porttitor.</p>
                                <p class="note">
                                    Ngô Xuân Lan <br>
                                    Trưởng phòng Marketing VCB
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>

<div class="modal fade" id="dangkykhoahoc" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Đăng ký khóa học</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                        <h3>Thông tin khóa học</h3>
                        <form>
                            <div class="form-group">
                                <label for="inputCourse">Lựa chọn khóa học</label>
                                <select class="form-control">
                                    <option>--Lựa chọn khóa học--</option>
                                    <option>Khóa học I</option>
                                    <option>Khóa học II</option>
                                    <option>Khóa học III</option>
                                    <option>Khóa học IV</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="inputCourseFee">Gói học phí</label>
                                <select class="form-control">
                                    <option>--Lựa chọn gói học phí--</option>
                                    <option>Gói I</option>
                                    <option>Gói II</option>
                                    <option>Gói III</option>
                                    <option>Gói IV</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="inputLocation">Địa điểm</label>
                                <select class="form-control">
                                    <option>Hà Nội</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="inputLocation">Thời gian</label>
                                <input type="date" class="form-control" id="inputDate">
                            </div>
                        </form>

                        <h3>Thông tin học viên</h3>
                        <div id="addHere">
                            <form id="student">
                                <div class="form-group">
                                    <label for="inputSex">Quý danh</label>
                                    <select class="form-control">
                                        <option>Ông</option>
                                        <option>Bà</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="inputName">Họ và tên</label>
                                    <input type="text" class="form-control" id="inputName" placeholder="Họ và tên">
                                </div>
                                <div class="form-group">
                                    <label for="inputPhone">Điện thoại</label>
                                    <input type="number" class="form-control" id="inputPhone" placeholder="Điện thoại">
                                </div>
                                <div class="form-group">
                                    <label for="inputMail">Email</label>
                                    <input type="number" class="form-control" id="inputMail" placeholder="Email">
                                </div>
                                <div class="form-group">
                                    <label for="inputCompany">Công ty</label>
                                    <input type="text" class="form-control" id="inputCompany" placeholder="Công ty">
                                </div>
                                <div class="form-group">
                                    <label for="inputStage">Chức vụ</label>
                                    <input type="text" class="form-control" id="inputStage" placeholder="Chức vụ">
                                </div>
                            </form>
                        </div>

                        <h3>Thông tin thêm</h3>
                        <form>
                            <div class="form-group">
                                <label for="inputCourse">Bạn biết đến khóa học qua</label>
                                <select class="form-control">
                                    <option>--Lựa chọn hình thức--</option>
                                    <option>Facebook</option>
                                    <option>Quảng cáo</option>
                                    <option>Tờ rơi</option>
                                    <option>Bạn bè</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="inputCourseFee">Loại hình thanh toán</label>
                                <select class="form-control">
                                    <option>--Lựa chọn hình thức--</option>
                                    <option>Tiền mặt</option>
                                    <option>Chuyển khoản</option>
                                    <option>Nợ</option>
                                </select>
                            </div>
                        </form>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                        <h4>ĐỂ ĐĂNG KÝ KHÓA HỌC XIN VUI LÒNG LIÊN HỆ TRỰC TIẾP</h4>
                        <ul>
                            <li>Địa chỉ: Đường abc, xyz, Hà Nội</li>
                            <li>Email: mail@eagleele.vn</li>
                            <li>Hotline: +84 1234 5678</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Đóng</button>
                <button type="button" id="addStudent" class="btn btn-default">Thêm người đăng ký</button>
                <button type="button" class="btn btn-primary btn-fill">Đăng ký</button>
            </div>
        </div>
    </div>
</div>

<!-- InstanceEndEditable -->