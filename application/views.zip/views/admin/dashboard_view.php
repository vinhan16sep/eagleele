<!--main content start-->
<div class="container">
    <h3>Informations</h3>
    <div class="col-lg-0" style="margin-top: 10px;">
        <table class="table table-hover table-bordered table-condensed">
            <thead>
                <tr>
                    <th colspan="2" class="col-md-3">Compornent</th>
                    <th>Actived items</th>
                    <th>Deleted items</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>
</div>
<!--main content end-->