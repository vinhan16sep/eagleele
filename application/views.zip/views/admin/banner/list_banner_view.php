<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<div class="container">
    <div class="row">
        <span><?php echo $this->session->flashdata('message'); ?></span>
    </div>
    <div class="row">
        <a type="button" href="<?php echo site_url('admin/banner/create'); ?>" class="btn btn-primary">ADD NEW</a>
    </div>
    <div class="row">
        <div class="col-lg-12" style="margin-top: 10px;">
            <?php
            echo '<table class="table table-hover table-bordered table-condensed">';
            if (!empty($banners)) {
                foreach ($banners as $item):
                    echo '<tr>';
                    echo '<img src="' . site_url('assets/upload/banner/' . $item['image']) . '"></img>';
//                    echo '<td><span class="' . (($item['is_actived'] == 0) ? 'glyphicon glyphicon-remove' : 'glyphicon glyphicon-ok') . '"></span></td>';
                    echo '<td>' . anchor('admin/banner/edit/' . $item['id'], '<span class="glyphicon glyphicon-pencil"></span>');
                    echo ' ' . anchor('admin/banner/delete/' . $item['id'], '<span class="glyphicon glyphicon-erase"></span>') . '</td>';
                    echo '</tr>';
                endforeach;
            }else {
                echo '<tr class="odd"><td colspan="9">No records</td></tr>';
            }
            echo '</table>';
            ?>
            <div class="col-md-6 col-md-offset-5">
                <?php echo $page_links; ?>
            </div>
        </div>
    </div>  
</div>
